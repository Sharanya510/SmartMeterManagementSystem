const DeleteFan = () => {
  return <div>DeleteFan</div>;
};
export default DeleteFan;
