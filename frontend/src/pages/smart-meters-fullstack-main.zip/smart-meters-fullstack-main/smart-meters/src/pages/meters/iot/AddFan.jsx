const AddFan = () => {
  return <div>AddFan</div>;
};
export default AddFan;
