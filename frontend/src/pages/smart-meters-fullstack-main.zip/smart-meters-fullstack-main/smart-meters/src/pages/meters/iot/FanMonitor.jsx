import { useEffect, useState } from 'react';
import { findAllFans } from '../../../services/deviceApi';

const FanMonitor = () => {
  const [lights, setLights] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const getAllMeters = async () => {
      try {
        const res = await findAllFans();

        if (res.status === 200) {
          setLights(res.data.meters);
          setLoading(false);
        }
      } catch (err) {
        console.log(err);
        setLoading(false);
      }
    };

    getAllMeters();
  }, []);

  if (loading) {
    return <p>Loading...</p>;
  }

  return (
    <div className='p-4'>
      <table className='table-auto'>
        <thead>
          <tr>
            <th className=''></th>
            <th className='border-8 border-white p-4 bg-gray-300'>Fan 1</th>
            <th className='border-8 border-white p-4 bg-gray-300'>Fan 2</th>
            <th className='border-8 border-white p-4 bg-gray-300'>Fan 3</th>
            <th className='border-8 border-white p-4 bg-gray-300'>Fan 4</th>
          </tr>

          <tr>
            <th className=''></th>
            <th className='border-4 border-white p-4'>
              <img
                src='/imgs/electry-meter.png'
                className='w-16 h-16 m-auto'
                alt=''
              />
            </th>
            <th className='border-4 border-white p-4'>
              <img
                src='/imgs/electry-meter.png'
                className='w-16 h-16 m-auto'
                alt=''
              />
            </th>
            <th className='border-4 border-white p-4'>
              <img
                src='/imgs/electry-meter.png'
                className='w-16 h-16 m-auto'
                alt=''
              />
            </th>
            <th className='border-4 border-white p-4'>
              <img
                src='/imgs/electry-meter.png'
                className='w-16 h-16 m-auto'
                alt=''
              />
            </th>
          </tr>
        </thead>
        <tbody className=''>
          <tr className='text-center font-bold'>
            <td className='text-left font-bold p-2 my-2'>Work status </td>
            <td className='p-2 my-2 text-green-500'>Working</td>
            <td className='p-2 my-2 text-green-500'>Working</td>
            <td className='p-2 my-2 text-green-500'>Working</td>
            <td className='p-2 my-2'>Not Working</td>
          </tr>
          <tr className='text-center font-bold'>
            <td className='text-left font-bold p-2 my-2'>
              Electricity Capacity{' '}
            </td>
            <td className='p-2 my-2'>70% </td>
            <td className='p-2 my-2'>60%</td>
            <td className='p-2 my-2'>40%</td>
            <td className='p-2 my-2'></td>
          </tr>
          <tr className='text-center font-bold'>
            <td className='text-left font-bold p-2 my-2'>Voltage </td>
            <td className='p-2 my-2'>200V</td>
            <td className='p-2 my-2'>200V</td>
            <td className='p-2 my-2'>100V</td>
            <td className='p-2 my-2'></td>
          </tr>

          <tr className='text-center font-bold'>
            <td className='text-left font-bold p-2 my-2'>Current </td>
            <td className='p-2 my-2'>10A</td>
            <td className='p-2 my-2'>10A</td>
            <td className='p-2 my-2'>5A</td>
            <td className='p-2 my-2'></td>
          </tr>

          <tr className='text-center font-bold'>
            <td className='text-left p-2 my-2'>Today Usage </td>
            <td className='p-2 my-2'>60KWh</td>
            <td className='p-2 my-2'>50KWh</td>
            <td className='p-2 my-2'>60KWh</td>
            <td className='p-2 my-2'></td>
          </tr>

          <tr className='text-center font-bold'>
            <td className='text-left p-2 my-2'>Last 24hr usage </td>
            <td className='p-2 my-2'>10KWh</td>
            <td className='p-2 my-2'>15KWh</td>
            <td className='p-2 my-2'>20KWh</td>
            <td className='p-2 my-2'></td>
          </tr>

          <tr className='text-center font-bold'>
            <td className='text-left p-2 my-2'>This week's usage </td>
            <td className='p-2 my-2'>10KWh</td>
            <td className='p-2 my-2'>15KWh</td>
            <td className='p-2 my-2'>20KWh</td>
            <td className='p-2 my-2'></td>
          </tr>

          <tr className='text-center font-bold'>
            <td className='text-left p-2 my-2'>This Months's usage </td>
            <td className='p-2 my-2'>10KWh</td>
            <td className='p-2 my-2'>15KWh</td>
            <td className='p-2 my-2'>20KWh</td>
            <td className='p-2 my-2'></td>
          </tr>

          <tr className='text-center font-bold'>
            <td className='text-left p-2 my-2'>This Year's usage </td>
            <td className='p-2 my-2'>10KWh</td>
            <td className='p-2 my-2'>15KWh</td>
            <td className='p-2 my-2'>20KWh</td>
            <td className='p-2 my-2'></td>
          </tr>
        </tbody>
      </table>
    </div>
  );
};

export default FanMonitor;
