const DeleteLight = () => {
  return <div>DeleteLight</div>;
};
export default DeleteLight;
