const UpdateFan = () => {
  return <div>UpdateFan</div>;
};
export default UpdateFan;
