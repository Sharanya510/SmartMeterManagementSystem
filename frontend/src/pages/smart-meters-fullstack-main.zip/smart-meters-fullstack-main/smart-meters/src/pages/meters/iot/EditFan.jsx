const EditFan = () => {
  return <div>EditFan</div>;
};
export default EditFan;
