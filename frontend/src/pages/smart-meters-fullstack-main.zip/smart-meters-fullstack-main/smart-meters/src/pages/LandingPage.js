import React from 'react'
import { useNavigate } from "react-router-dom";
import '../styles/landingPage.css'

export const LandingPage = () => {
    const navigate = useNavigate();

    const handleLoginpage = (event) => {
        navigate("/login");
      };

    return (      
            <div className='backgroundImage'
            style={{backgroundImage: `url("https://www.xenonstack.com/hubfs/xenonstack-smart-meter-iot-solutions.png")` }}>
                        <label className="primary-label">To navigate inside, Click on login </label>
                    <button className="primary-button" onClick={handleLoginpage}>Log in</button>
               
            </div>
        
    )
}

const HeaderStyle = {
    width: "100%",
    height: "100vh",
    background: "teal",
    backgroundPosition: "center",
    backgroundRepeat: "no-repeat",
    backgroundSize: "cover"
}