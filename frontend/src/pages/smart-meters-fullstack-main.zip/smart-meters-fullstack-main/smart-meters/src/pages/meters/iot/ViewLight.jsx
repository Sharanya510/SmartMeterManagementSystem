const ViewLight = () => {
  return <div>ViewLight</div>;
};
export default ViewLight;
