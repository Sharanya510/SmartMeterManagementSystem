const WaterHome = () => {
  return <div>WaterHome</div>;
};
export default WaterHome;
