import { Outlet } from 'react-router-dom';

const ConfigHome = () => {
  return <Outlet />;
};

export default ConfigHome;
