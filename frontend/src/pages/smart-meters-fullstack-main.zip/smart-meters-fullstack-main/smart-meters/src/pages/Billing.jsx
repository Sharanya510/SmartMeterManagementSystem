const Billing = () => {
  return (
    <div className='p-4'>
      <h1 className='text-3xl my-4'>Billing</h1>

      <table className='table-auto w-3/4 border-collapse'>
        <thead>
          <tr className='text-left'>
            <th className='p-4 bg-gray-300 border border-black'>Device name</th>
            <th className='p-4 bg-gray-300 border border-black'>
              Units consumed
            </th>
            <th className='p-4 bg-gray-300 border border-black'>
              Cost per Unit
            </th>
            <th className='p-4 bg-gray-300 border border-black'>Total Cost</th>
            <th className='p-4 bg-gray-300 border border-black'>Density</th>
          </tr>
        </thead>
        <tbody className='divide-y divide-y-zinc-300'>
          <tr>
            <td className='p-2'>Lamp1</td>
            <td className='p-2'>75</td>
            <td className='p-2'>11</td>
            <td className='p-2'>3,287,263</td>
            <td className='p-2'>0.00</td>
          </tr>
          <tr>
            <td className='p-2'>Lamp1</td>
            <td className='p-2'>75</td>
            <td className='p-2'>11</td>
            <td className='p-2'>3,287,263</td>
            <td className='p-2'>0.00</td>
          </tr>
          <tr>
            <td className='p-2'>Lamp1</td>
            <td className='p-2'>75</td>
            <td className='p-2'>11</td>
            <td className='p-2'>3,287,263</td>
            <td className='p-2'>0.00</td>
          </tr>
        </tbody>
      </table>
    </div>
  );
};

export default Billing;
