import { Outlet } from 'react-router-dom';

const IotDevices = () => {
  return <Outlet />;
};

export default IotDevices;
