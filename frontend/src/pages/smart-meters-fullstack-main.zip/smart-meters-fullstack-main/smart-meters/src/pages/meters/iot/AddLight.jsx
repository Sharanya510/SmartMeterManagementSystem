const AddLight = () => {
  return <div>AddLight</div>;
};
export default AddLight;
