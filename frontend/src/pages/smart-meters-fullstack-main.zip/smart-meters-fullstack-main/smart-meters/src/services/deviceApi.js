import axios from 'axios';

export const findDeviceById = async (id) => {
  return await axios.get(`/api/fan/getMeterById?id=${id}`);
};

export const findAllDevices = async () => {
  return await axios.get('/api/fan/getAllMeters');
};

export const addDevice = async (data) => {
  return await axios.post('/api/fan/addMeterdetails', data);
};

export const updateDevice = async (id, data) => {
  return await axios.post(`/api/fan/updateMeter?id=${id}`, data);
};

export const deleteDevice = async (id) => {
  return await axios.get(`/api/fan/deleteMeter?id=${id}`);
};

// fans
export const findAllFans = async () => {
  return await axios.get('/api/fan/getAllFans');
};

export const findFanById = async (id) => {
  return await axios.get(`/api/fan/getFanById?id=${id}`);
};

export const addFan = async (data) => {
  return await axios.post('/api/fan/addFandetails', data);
};

export const updateFan = async (id, data) => {
  return await axios.post(`/api/fan/updateFandetails?id=${id}`, data);
};

export const deleteFan = async (id) => {
  return await axios.get(`/api/fan/deleteFandetails?id=${id}`);
};

// lights
export const findAllLights = async () => {
  return await axios.get('/api/fan/getAllLight');
};

export const findLightById = async (id) => {
  return await axios.get(`/api/fan/getLightById?id=${id}`);
};

export const addLight = async (data) => {
  return await axios.post('/api/fan/addLightdetails', data);
};

export const updateLight = async (id, data) => {
  return await axios.post(`/api/fan/updateLight?id=${id}`, data);
};

export const deleteLight = async (id) => {
  return await axios.get(`/api/fan/deleteLight?id=${id}`);
};
